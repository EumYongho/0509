package com.ohmycar.mapper;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ohmycar.domain.BoardVO;
import com.ohmycar.persistence.TimeMapperTests;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Autowired
	private BoardMapper mapper;

	@Test
	public void testGetList() {
		mapper.getList().forEach(board -> log.info(board));
	}
	
	@Test
	public void testInsert() {
		BoardVO board = new BoardVO();
		board.setUserId("06");
		board.setCarId("EESD24E");
		board.setCarSellName("Santafe");
		board.setCarName("��Ÿ��");
		board.setCarType("2.0T");
		
		mapper.insert(board);
		log.info(board);
	}
	
	
	@Test
	public void testInsertSelectKey() {
	    BoardVO board = new BoardVO();
	    board.setUserId("new Id");
	    board.setCarId("new select key");
	    board.setCarSellName("new select key");
	    board.setCarName("Sonata");
	    board.setCarType("SE");

	    mapper.insertSelectKey(board);
	    log.info(board);
	  
	}
	
	@Test
	public void testRead() {
		BoardVO board = mapper.read(6L);
		log.info(board);
	}
	
	@Test
	public void testDelete() {
                       //������ ������ȣ Ȯ��
		log.info("DELETE COUNT :" + mapper.delete(12L));
	}
	
	@Test
	public void testUpdate() {
		BoardVO board = new BoardVO();
                       //������ �����ϴ� ��ȣ���� Ȯ���� ��
		board.setUserNum(6L);		
		board.setUserId("������ Id");
		board.setCarId("������ Id");
		board.setCarSellName("������ Name");
		board.setCarName("Staria");
		board.setCarType("EV");
		
		int count = mapper.update(board);
		log.info("UPDATE COUNT: " + count);
	}
}
