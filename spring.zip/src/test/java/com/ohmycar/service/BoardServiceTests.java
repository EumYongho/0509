package com.ohmycar.service;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ohmycar.domain.BoardVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTests {
	@Autowired
	private BoardService service;

	@Test
	public void testRegister() {
		BoardVO board = new BoardVO();
		board.setUserId("���� �����ϴ� Id");
		board.setCarId("���� �����ϴ� Car");
		board.setCarSellName("���� Poter");
		board.setCarName("���� ����");
		board.setCarType("ev");
		service.register(board);
		log.info("������ �Խù��� ��ȣ: " + board.getUserNum());
	}

	@Test
	public void testGetList() {
		service.getList().forEach(board -> log.info(board));
	}

	@Test
	public void testGet() {
		log.info(service.get(8L));
	}

	@Test
	public void testDelete() {
		// ��ȣ�� �ִ��� Ȯ��
		log.info("REMOVE RESULT : " + service.remove(5L));
	}

	@Test
	public void testUpdate() {
		// ��ȣ�� �ִ��� Ȯ��
		BoardVO board = service.get(6L);

		if (board == null) {
			return;
		}

		board.setUserId("���� �����մϴ�.");
		log.info("MODIFY RESULT: " + service.modify(board));
	}
}
