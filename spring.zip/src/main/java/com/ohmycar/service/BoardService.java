package com.ohmycar.service;

import java.util.List;

import com.ohmycar.domain.BoardVO;

public interface BoardService {
	public void register(BoardVO board);

	public BoardVO get(Long userNum);

	public boolean modify(BoardVO board);

	public boolean remove(Long userNum);

	public List<BoardVO> getList();
}
