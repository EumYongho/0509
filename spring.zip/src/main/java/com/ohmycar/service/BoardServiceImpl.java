package com.ohmycar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ohmycar.domain.BoardVO;
import com.ohmycar.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardMapper mapper;

	@Override
	public BoardVO get(Long userNum) {
		log.info("get....." + userNum);
		return mapper.read(userNum);
	}

	@Override
	public boolean modify(BoardVO board) {
		log.info("modify.... " + board);
		return mapper.update(board) == 1;
	}

	@Override
	public boolean remove(Long userNum) {
		log.info("remove...." + userNum);
		return mapper.delete(userNum) == 1;
	}

	@Override
	public List<BoardVO> getList() {
		log.info("getList.....");
		return mapper.getList();
	}

	@Override
	public void register(BoardVO board) {
		log.info("register....." + board);
		mapper.insertSelectKey(board);

	}

}
