package com.ohmycar.domain;

import java.util.Date;
import lombok.Data;

@Data
public class BoardVO {
	private Long userNum;
	private String userId;
	private String carId;
	private String carSellName;
	private String carName;
	private String carType;
	private Date updateDate;

	@Override
	public String toString() {
		return "BoardVO [userNum=" + userNum + ", userId=" + userId + ", carId=" + carId + ", carSellName="
				+ carSellName + ", carName=" + carName + ", carType=" + carType + ", updateDate=" + updateDate
				+ ", getUserNum()=" + getUserNum() + ", getUserId()=" + getUserId() + ", getCarId()=" + getCarId()
				+ ", getCarSellName()=" + getCarSellName() + ", getCarName()=" + getCarName() + ", getCarType()="
				+ getCarType() + ", getUpdateDate()=" + getUpdateDate() + ", hashCode()=" + hashCode() + ", getClass()="
				+ getClass() + ", toString()=" + super.toString() + "]";
	}

}
